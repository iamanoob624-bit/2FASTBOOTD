# Minerally — 1.12.2 reimplementation (for private use, with permission)

A clean-room 1.12.2 Forge recreation of theone_ss's **Minerally** (Fabric, 1.19.2),
built with the original author's permission. Only the compiled jar was available (no
source), so this isn't a line-by-line port — the original art assets are reused
directly, but every line of Java here is new, written against 1.12.2's own APIs.

## What's included

- **8 piles** (coal, iron, gold, copper, redstone, lapis, netherite, nether gold) —
  attach to any of the 6 faces of a solid block, like a vanilla amethyst cluster.
- **3 crystals** (diamond, emerald, quartz) — same attachment behavior as piles.
- **10 mineral rocks** (one per mineral above except nether gold) — simpler,
  floor-standing, single-hit.
- **2 geodes** (overworld, Nether) — decorative only; they drop *nothing* unless mined
  with Silk Touch, matching the original's loot tables exactly (there's no non-silk
  loot entry for geodes at all in the source data).
- World generation scattering all of the above through overworld caves and, for the
  Nether-specific ones, the Nether.

## Content that had to change for this era

1.19.2 → 1.12.2 spans several updates that added game concepts from scratch:

- **No deepslate** (added 1.17): all "deepslate_X" variants were merged into their
  regular counterpart — there's no deepslate layer for them to look distinct on.
- **No copper** (added 1.17): `copper_pile`/`copper_rock` drop a new placeholder item,
  **Raw Copper Chunk** — a plain collectible with no further use (no smelting, no
  copper block). Its texture is an original 16×16 icon I made for this port, not from
  the original mod.
- **No netherite** (added 1.16): `netherite_pile`/`netherite_rock` drop a new
  placeholder item, **Unrefined Netherite Chunk**, same deal — collectible only, new
  original icon.
- **No raw ore items** (added 1.17): iron/gold piles and rocks drop the **ore block
  item** instead (`iron_ore`/`gold_ore`) — this is what mining those ores actually gave
  you in 1.12.2; you'd smelt the block into ingots exactly like vanilla.
- **No Magma Block texture** (added 1.13): the Nether geode's model referenced
  `minecraft:block/magma` for one layer; swapped for `minecraft:blocks/glowstone`.

## Design decisions worth knowing about

- **Explosions drop nothing.** `harvestBlock` (the player-mines-it path) is fully
  implemented, but `getDrops` (used for TNT/creeper destruction) is intentionally left
  empty. Interestingly, the original's loot tables do have an explosion-survival
  condition on some entries, suggesting the original handles this case — this port
  doesn't, as a scope simplification. Easy to add if it matters to you.
- **Fortune scaling**: applied to everything except iron/gold/nether-gold (matching
  vanilla, where fortune doesn't affect ore blocks that drop themselves).
- **3 cosmetic size variants → 1.** The original registers 3 near-identical blocks per
  pile/crystal type (e.g. `iron_pile`, `iron_pile_0`, `iron_pile_1`) with byte-for-byte
  identical loot tables — they're purely a visual-variety mechanic. This port just uses
  the primary (largest) variant's model per mineral. Adding the other two back is a
  matter of copying one more model/blockstate file and one more registration line per
  type, if you want the extra visual variety later.
- **World generation rarity is a rough guess**, not tuned against the original (which I
  have no way to inspect). Look in `MinerallyWorldGen.java` — the per-chunk attempt
  counts and `random.nextInt(N)` gates are the easiest numbers to tweak if things feel
  too sparse or too common once you're playing.

## Things to double-check on first compile

Consistent with the last two ports — no internet access in the build environment to
verify against the real 1.12.2 classes, so these are informed-but-unverified:
- `PropertyDirection.create("facing")` (all 6 `EnumFacing` values, no filter) —
  confident this overload exists, used by several vanilla blocks.
- `BlockFaceShape.UNDEFINED` and `IBlockState#isSideSolid(...)` — standard by 1.12.2 as
  far as I know.
- `Block#setSoundType(SoundType)` — the 1.12.2-era name for what's `setStepSound` in
  even older versions.

## Building

Same workflow as the last two: merge `src/main/java/theone_ss` and
`src/main/resources` from this zip into a fresh copy of the **official Forge 1.12.2
MDK**, then `./gradlew build` from there. Ask if you want the full copy-paste steps
again.
