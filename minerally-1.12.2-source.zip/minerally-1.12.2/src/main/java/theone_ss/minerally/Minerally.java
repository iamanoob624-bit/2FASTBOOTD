package theone_ss.minerally;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import org.apache.logging.log4j.Logger;
import theone_ss.minerally.registry.MinerallyBlocks;
import theone_ss.minerally.worldgen.MinerallyWorldGen;

/**
 * A clean-room 1.12.2 reimplementation of theone_ss's "Minerally" (Fabric, 1.19.2),
 * built with the author's permission. Only the compiled jar was available (no source),
 * so this is not a line-by-line port - see README.md for the full list of design
 * decisions, especially around content that didn't exist yet in 1.12.2 (deepslate,
 * copper, netherite, raw ore items).
 */
@Mod(modid = Minerally.MOD_ID, name = Minerally.NAME, version = Minerally.VERSION,
        acceptedMinecraftVersions = "[1.12.2]")
public class Minerally {
    public static final String MOD_ID = "minerally";
    public static final String NAME = "Minerally";
    public static final String VERSION = "1.12.2-port-1.0.0";
    public static Logger LOGGER;

    @Mod.Instance(MOD_ID)
    public static Minerally INSTANCE;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER = event.getModLog();
        MinerallyBlocks.registerModels();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        GameRegistry.registerWorldGenerator(new MinerallyWorldGen(), 2);
    }
}
