package theone_ss.minerally.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import java.util.List;
import java.util.Random;

/**
 * Shared base for piles, crystals, and geodes - all of them are small decorative
 * clusters that can attach to any of the 6 faces of a solid block (same idea as
 * vanilla amethyst clusters in later versions, or how BlockLever/BlockTorch attach in
 * 1.12.2, just generalized to every face rather than just up/down/sides).
 *
 * silkTouchOnly=true (used for geodes) means the block only ever drops itself, and
 * only with Silk Touch - mining it any other way yields nothing, matching the
 * original's loot tables (geodes have no non-silk-touch loot entry at all).
 */
public class DirectionalMineralBlock extends Block {
    public static final PropertyDirection FACING = PropertyDirection.create("facing");

    private final ItemStack dropStack;
    private final boolean silkTouchOnly;
    private final boolean fortuneAffected;

    public DirectionalMineralBlock(String registryName, ItemStack dropStack, boolean silkTouchOnly, boolean fortuneAffected) {
        super(Material.ROCK);
        this.dropStack = dropStack;
        this.silkTouchOnly = silkTouchOnly;
        this.fortuneAffected = fortuneAffected;
        this.setTranslationKey(registryName);
        this.setHardness(1.0F);
        this.setSoundType(net.minecraft.block.SoundType.STONE);
        this.setDefaultState(this.blockState.getBaseState().withProperty(FACING, EnumFacing.UP));
    }

    @Override
    protected BlockStateContainer createBlockState() {
        return new BlockStateContainer(this, FACING);
    }

    @Override
    public IBlockState getStateFromMeta(int meta) {
        EnumFacing facing = EnumFacing.getFront(meta);
        if (facing == null) facing = EnumFacing.UP;
        return this.getDefaultState().withProperty(FACING, facing);
    }

    @Override
    public int getMetaFromState(IBlockState state) {
        return state.getValue(FACING).getIndex();
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public BlockFaceShape getBlockFaceShape(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
        return BlockFaceShape.UNDEFINED;
    }

    @Override
    public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos) {
        EnumFacing facing = state.getValue(FACING);
        double pad = 0.2;
        double depth = 0.55;
        switch (facing) {
            case DOWN:
                return new AxisAlignedBB(pad, 1 - depth, pad, 1 - pad, 1, 1 - pad);
            case UP:
                return new AxisAlignedBB(pad, 0, pad, 1 - pad, depth, 1 - pad);
            case NORTH:
                return new AxisAlignedBB(pad, pad, 1 - depth, 1 - pad, 1 - pad, 1);
            case SOUTH:
                return new AxisAlignedBB(pad, pad, 0, 1 - pad, 1 - pad, depth);
            case WEST:
                return new AxisAlignedBB(1 - depth, pad, pad, 1, 1 - pad, 1 - pad);
            case EAST:
            default:
                return new AxisAlignedBB(0, pad, pad, depth, 1 - pad, 1 - pad);
        }
    }

    private boolean hasSupport(World world, BlockPos pos, EnumFacing facing) {
        BlockPos supportPos = pos.offset(facing.getOpposite());
        IBlockState supportState = world.getBlockState(supportPos);
        return supportState.isSideSolid(world, supportPos, facing);
    }

    @Override
    public boolean canPlaceBlockAt(World worldIn, BlockPos pos) {
        for (EnumFacing facing : EnumFacing.values()) {
            if (hasSupport(worldIn, pos, facing)) {
                return true;
            }
        }
        return false;
    }

    /** Used by world generation to place directly with a known, already-validated facing. */
    public boolean canAttach(World world, BlockPos pos, EnumFacing facing) {
        return hasSupport(world, pos, facing);
    }

    @Override
    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block blockIn, BlockPos fromPos) {
        EnumFacing facing = state.getValue(FACING);
        if (!hasSupport(world, pos, facing)) {
            world.setBlockToAir(pos);
        }
    }

    @Override
    public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
        return true;
    }

    @Override
    public void getDrops(List<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
        // Deliberately does NOT call the harvesters-tool / silk-touch check here since
        // that information isn't available on this overload; the real gating happens
        // in harvestBlock below, which vanilla always calls before this in survival.
    }

    @Override
    public void harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state, net.minecraft.tileentity.TileEntity te, ItemStack stack) {
        boolean silkTouch = EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, stack) > 0;

        if (silkTouch) {
            spawnAsEntity(worldIn, pos, new ItemStack(Item.getItemFromBlock(this)));
        } else if (!this.silkTouchOnly) {
            int fortune = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, stack);
            ItemStack toDrop = this.dropStack.copy();
            if (this.fortuneAffected && fortune > 0) {
                Random rand = worldIn.rand;
                toDrop.setCount(toDrop.getCount() + rand.nextInt(fortune + 1));
            }
            spawnAsEntity(worldIn, pos, toDrop);
        }
        // silkTouchOnly=true and no silk touch: nothing drops, matching the original's
        // loot table (geodes have no non-silk-touch loot entry).

        worldIn.setBlockToAir(pos);
    }
}
