package theone_ss.minerally.block;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

import java.util.Random;

/**
 * A small decorative rock that always sits upright on the floor - no facing
 * property, single hit, no multi-face attachment needed. Same drop behavior as
 * DirectionalMineralBlock, just without the direction handling.
 */
public class MineralRockBlock extends Block {
    private static final AxisAlignedBB SHAPE = new AxisAlignedBB(0.2, 0, 0.2, 0.8, 0.4, 0.8);

    private final ItemStack dropStack;
    private final boolean fortuneAffected;

    public MineralRockBlock(String registryName, ItemStack dropStack, boolean fortuneAffected) {
        super(Material.ROCK);
        this.dropStack = dropStack;
        this.fortuneAffected = fortuneAffected;
        this.setTranslationKey(registryName);
        this.setHardness(1.0F);
        this.setSoundType(net.minecraft.block.SoundType.STONE);
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public BlockFaceShape getBlockFaceShape(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
        return BlockFaceShape.UNDEFINED;
    }

    @Override
    public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos) {
        return SHAPE;
    }

    @Override
    public boolean canPlaceBlockAt(World worldIn, BlockPos pos) {
        return worldIn.getBlockState(pos.down()).isSideSolid(worldIn, pos.down(), EnumFacing.UP);
    }

    @Override
    public void neighborChanged(IBlockState state, World world, BlockPos pos, Block blockIn, BlockPos fromPos) {
        if (!world.getBlockState(pos.down()).isSideSolid(world, pos.down(), EnumFacing.UP)) {
            world.setBlockToAir(pos);
        }
    }

    @Override
    public boolean canSilkHarvest(World world, BlockPos pos, IBlockState state, EntityPlayer player) {
        return true;
    }

    @Override
    public void harvestBlock(World worldIn, EntityPlayer player, BlockPos pos, IBlockState state, net.minecraft.tileentity.TileEntity te, ItemStack stack) {
        boolean silkTouch = EnchantmentHelper.getEnchantmentLevel(Enchantments.SILK_TOUCH, stack) > 0;

        if (silkTouch) {
            spawnAsEntity(worldIn, pos, new ItemStack(Item.getItemFromBlock(this)));
        } else {
            int fortune = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, stack);
            ItemStack toDrop = this.dropStack.copy();
            if (this.fortuneAffected && fortune > 0) {
                Random rand = worldIn.rand;
                toDrop.setCount(toDrop.getCount() + rand.nextInt(fortune + 1));
            }
            spawnAsEntity(worldIn, pos, toDrop);
        }

        worldIn.setBlockToAir(pos);
    }
}
