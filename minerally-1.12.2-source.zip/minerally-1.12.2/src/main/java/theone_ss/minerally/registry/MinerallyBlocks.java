package theone_ss.minerally.registry;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import theone_ss.minerally.Minerally;
import theone_ss.minerally.block.DirectionalMineralBlock;
import theone_ss.minerally.block.MineralRockBlock;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = Minerally.MOD_ID)
public class MinerallyBlocks {

    public static final List<Block> ALL_BLOCKS = new ArrayList<>();

    // Piles - overworld, attach to any face.
    public static final Block COAL_PILE = pile("coal_pile", new ItemStack(Items.COAL), false, true);
    public static final Block IRON_PILE = pile("iron_pile", new ItemStack(Item.getItemFromBlock(Blocks.IRON_ORE)), false, false);
    public static final Block GOLD_PILE = pile("gold_pile", new ItemStack(Item.getItemFromBlock(Blocks.GOLD_ORE)), false, false);
    public static final Block COPPER_PILE = pile("copper_pile", new ItemStack(MinerallyItems.RAW_COPPER_CHUNK), false, true);
    public static final Block REDSTONE_PILE = pile("redstone_pile", new ItemStack(Items.REDSTONE), false, true);
    public static final Block LAPIS_PILE = pile("lapis_pile", new ItemStack(Items.DYE, 1, 4), false, true);

    // Piles - Nether only.
    public static final Block NETHERITE_PILE = pile("netherite_pile", new ItemStack(MinerallyItems.UNREFINED_NETHERITE_CHUNK), false, true);
    public static final Block NETHER_GOLD_PILE = pile("nether_gold_pile", new ItemStack(Item.getItemFromBlock(Blocks.GOLD_ORE)), false, false);

    // Crystals - overworld.
    public static final Block DIAMOND_CRYSTAL = pile("diamond_crystal", new ItemStack(Items.DIAMOND), false, true);
    public static final Block EMERALD_CRYSTAL = pile("emerald_crystal", new ItemStack(Items.EMERALD), false, true);
    public static final Block QUARTZ_CRYSTAL = pile("quartz_crystal", new ItemStack(Items.QUARTZ), false, true);

    // Rocks - overworld.
    public static final Block COAL_ROCK = rock("coal_rock", new ItemStack(Items.COAL), true);
    public static final Block IRON_ROCK = rock("iron_rock", new ItemStack(Item.getItemFromBlock(Blocks.IRON_ORE)), false);
    public static final Block GOLD_ROCK = rock("gold_rock", new ItemStack(Item.getItemFromBlock(Blocks.GOLD_ORE)), false);
    public static final Block COPPER_ROCK = rock("copper_rock", new ItemStack(MinerallyItems.RAW_COPPER_CHUNK), true);
    public static final Block REDSTONE_ROCK = rock("redstone_rock", new ItemStack(Items.REDSTONE), true);
    public static final Block LAPIS_ROCK = rock("lapis_rock", new ItemStack(Items.DYE, 1, 4), true);
    public static final Block NETHERITE_ROCK = rock("netherite_rock", new ItemStack(MinerallyItems.UNREFINED_NETHERITE_CHUNK), true);
    public static final Block DIAMOND_ROCK = rock("diamond_rock", new ItemStack(Items.DIAMOND), true);
    public static final Block EMERALD_ROCK = rock("emerald_rock", new ItemStack(Items.EMERALD), true);
    public static final Block QUARTZ_ROCK = rock("quartz_rock", new ItemStack(Items.QUARTZ), true);

    // Geodes - silk touch only. One overworld, one Nether.
    public static final Block GEODE = pile("geode", ItemStack.EMPTY, true, false);
    public static final Block NETHER_GEODE = pile("nether_geode", ItemStack.EMPTY, true, false);

    private static Block pile(String name, ItemStack drop, boolean silkOnly, boolean fortune) {
        Block b = new DirectionalMineralBlock(name, drop, silkOnly, fortune);
        b.setRegistryName(Minerally.MOD_ID, name);
        ALL_BLOCKS.add(b);
        return b;
    }

    private static Block rock(String name, ItemStack drop, boolean fortune) {
        Block b = new MineralRockBlock(name, drop, fortune);
        b.setRegistryName(Minerally.MOD_ID, name);
        ALL_BLOCKS.add(b);
        return b;
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        for (Block b : ALL_BLOCKS) {
            event.getRegistry().register(b);
        }
    }

    @SubscribeEvent
    public static void registerItemBlocks(RegistryEvent.Register<Item> event) {
        for (Block b : ALL_BLOCKS) {
            ItemBlock itemBlock = new ItemBlock(b);
            itemBlock.setRegistryName(b.getRegistryName());
            itemBlock.setCreativeTab(MinerallyItems.TAB);
            event.getRegistry().register(itemBlock);
        }
    }

    public static void registerModels() {
        for (Block b : ALL_BLOCKS) {
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(b), 0,
                    new ModelResourceLocation(b.getRegistryName(), "inventory"));
        }
    }
}
