package theone_ss.minerally.registry;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import theone_ss.minerally.Minerally;

/**
 * Copper and netherite don't exist at all in 1.12.2 (added in 1.17 and 1.16
 * respectively), so copper_pile/copper_rock and netherite_pile/netherite_rock drop
 * these two plain placeholder items instead of a "raw" vanilla item. They have no
 * further use (no smelting recipe, no tool/armor tier) - they're collectible-only
 * unless you build more around them.
 */
@Mod.EventBusSubscriber(modid = Minerally.MOD_ID)
public class MinerallyItems {

    public static final CreativeTabs TAB = new CreativeTabs("minerally") {
        @Override
        public ItemStack getTabIconItem() {
            return new ItemStack(RAW_COPPER_CHUNK);
        }
    };

    public static final Item RAW_COPPER_CHUNK = new Item()
            .setRegistryName(Minerally.MOD_ID, "raw_copper_chunk")
            .setTranslationKey(Minerally.MOD_ID + ".raw_copper_chunk")
            .setCreativeTab(TAB);

    public static final Item UNREFINED_NETHERITE_CHUNK = new Item()
            .setRegistryName(Minerally.MOD_ID, "unrefined_netherite_chunk")
            .setTranslationKey(Minerally.MOD_ID + ".unrefined_netherite_chunk")
            .setCreativeTab(TAB);

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(RAW_COPPER_CHUNK, UNREFINED_NETHERITE_CHUNK);
    }

    public static void registerModels() {
        registerItemModel(RAW_COPPER_CHUNK);
        registerItemModel(UNREFINED_NETHERITE_CHUNK);
    }

    private static void registerItemModel(Item item) {
        net.minecraftforge.client.model.ModelLoader.setCustomModelResourceLocation(item, 0,
                new net.minecraft.client.renderer.block.model.ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
