package theone_ss.minerally.worldgen;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkGenerator;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraftforge.fml.common.IWorldGenerator;
import theone_ss.minerally.block.DirectionalMineralBlock;
import theone_ss.minerally.block.MineralRockBlock;
import theone_ss.minerally.registry.MinerallyBlocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Scatters the mod's blocks during chunk generation. This is a from-scratch design -
 * 1.12.2's IWorldGenerator API (this whole file) has nothing structurally in common
 * with 1.19's feature/placement system, so there was no original logic to carry over
 * here regardless of source availability.
 *
 * Overworld: attempts a handful of directional-block placements (piles + crystals)
 * between Y 5-50, plus a couple of floor-rock placements, plus a rare geode.
 * Nether: attempts nether-gold-pile, netherite-pile, netherite-rock, and nether_geode
 * placements against netherrack in open cave-like pockets.
 */
public class MinerallyWorldGen implements IWorldGenerator {

    private static final List<DirectionalMineralBlock> OVERWORLD_DIRECTIONAL = new ArrayList<>();
    private static final List<MineralRockBlock> OVERWORLD_ROCKS = new ArrayList<>();
    private static final List<DirectionalMineralBlock> NETHER_DIRECTIONAL = new ArrayList<>();
    private static final List<MineralRockBlock> NETHER_ROCKS = new ArrayList<>();

    static {
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.COAL_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.IRON_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.GOLD_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.COPPER_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.REDSTONE_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.LAPIS_PILE);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.DIAMOND_CRYSTAL);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.EMERALD_CRYSTAL);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.QUARTZ_CRYSTAL);
        OVERWORLD_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.GEODE);

        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.COAL_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.IRON_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.GOLD_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.COPPER_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.REDSTONE_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.LAPIS_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.DIAMOND_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.EMERALD_ROCK);
        OVERWORLD_ROCKS.add((MineralRockBlock) MinerallyBlocks.QUARTZ_ROCK);

        NETHER_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.NETHERITE_PILE);
        NETHER_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.NETHER_GOLD_PILE);
        NETHER_DIRECTIONAL.add((DirectionalMineralBlock) MinerallyBlocks.NETHER_GEODE);

        NETHER_ROCKS.add((MineralRockBlock) MinerallyBlocks.NETHERITE_ROCK);
    }

    @Override
    public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator, IChunkProvider chunkProvider) {
        int dimension = world.provider.getDimension();
        int baseX = chunkX * 16;
        int baseZ = chunkZ * 16;

        if (dimension == 0) {
            generateOverworld(random, world, baseX, baseZ);
        } else if (dimension == -1) {
            generateNether(random, world, baseX, baseZ);
        }
    }

    private void generateOverworld(Random random, World world, int baseX, int baseZ) {
        // Directional piles/crystals: a handful of attempts per chunk, most fail
        // silently (no valid cave air pocket found), which is intentional - it keeps
        // these rare rather than guaranteed-per-chunk.
        for (int i = 0; i < 6; i++) {
            if (random.nextInt(3) != 0) continue; // ~2 real attempts per chunk on average
            Block choice = OVERWORLD_DIRECTIONAL.get(random.nextInt(OVERWORLD_DIRECTIONAL.size()));
            tryPlaceDirectional(random, world, baseX, baseZ, 5, 50, choice);
        }

        for (int i = 0; i < 3; i++) {
            if (random.nextInt(4) != 0) continue;
            Block choice = OVERWORLD_ROCKS.get(random.nextInt(OVERWORLD_ROCKS.size()));
            tryPlaceRock(random, world, baseX, baseZ, 5, 50, choice);
        }
    }

    private void generateNether(Random random, World world, int baseX, int baseZ) {
        for (int i = 0; i < 4; i++) {
            if (random.nextInt(4) != 0) continue;
            Block choice = NETHER_DIRECTIONAL.get(random.nextInt(NETHER_DIRECTIONAL.size()));
            tryPlaceDirectional(random, world, baseX, baseZ, 10, 120, choice);
        }

        for (int i = 0; i < 2; i++) {
            if (random.nextInt(5) != 0) continue;
            tryPlaceRock(random, world, baseX, baseZ, 10, 120, MinerallyBlocks.NETHERITE_ROCK);
        }
    }

    private void tryPlaceDirectional(Random random, World world, int baseX, int baseZ, int minY, int maxY, Block block) {
        int x = baseX + random.nextInt(16);
        int z = baseZ + random.nextInt(16);
        int y = minY + random.nextInt(Math.max(1, maxY - minY));
        BlockPos pos = new BlockPos(x, y, z);

        if (!world.isAirBlock(pos)) return;

        DirectionalMineralBlock dBlock = (DirectionalMineralBlock) block;
        List<EnumFacing> validFaces = new ArrayList<>();
        for (EnumFacing facing : EnumFacing.values()) {
            if (dBlock.canAttach(world, pos, facing)) {
                validFaces.add(facing);
            }
        }
        if (validFaces.isEmpty()) return;

        EnumFacing facing = validFaces.get(random.nextInt(validFaces.size()));
        IBlockState state = block.getDefaultState().withProperty(DirectionalMineralBlock.FACING, facing);
        world.setBlockState(pos, state, 2);
    }

    private void tryPlaceRock(Random random, World world, int baseX, int baseZ, int minY, int maxY, Block block) {
        int x = baseX + random.nextInt(16);
        int z = baseZ + random.nextInt(16);
        int y = minY + random.nextInt(Math.max(1, maxY - minY));
        BlockPos pos = new BlockPos(x, y, z);

        if (!world.isAirBlock(pos)) return;
        if (!((MineralRockBlock) block).canPlaceBlockAt(world, pos)) return;

        world.setBlockState(pos, block.getDefaultState(), 2);
    }
}
